# NewToneLib
NewToneLib is a simple library, intended for devices which do not support built-in tone() function.

NOTE: tone() function does not support using multiple pins simultaneously.

Tested on the following devices:<br/>
  -NodeMCU v1.0(ESP-12E) with ESP8266<br/>
  -Arduino Due<br/>
  
Feel free to report any issues you encounter with the library and test on another devices.<br/>
Any help would be appreciated. :)

created:   January 2020<br/>
by Yordan Yordanov, BG
